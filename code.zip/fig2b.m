clear
clc
a1=1;
a2=0.1;%0.7980981536e-1;
a3=3;
a4=1.8;
u(1)=1.1;
v(1)=0.9;
nt=20000;
h=0.01;
 tau=0.0;
 j=1;
s=0.01:0.001:2;
 for a1=s
    for i=1:nt   
        if(i>fix(tau/h))
            ud=u(i-fix(tau/h));
            vd=v(i-fix(tau/h));
        else
            ud=0;
            vd=0;
        end  
    u(i+1)=u(i)+h*(a1-a2*ud-a3*u(i)*v(i)^2); 
    v(i+1)=v(i)+h*(a2*ud+a3*u(i)*v(i)^2-a4*v(i));
    end
  s1(j)=max(v(end-2000:end));
  s2(j)=min(v(end-2000:end));
  j=j+1;
 end
    
plot(s,s1,'LineWidth',2)
hold on 
plot(s,s2,'LineWidth',2)
xlabel('a_1','FontSize',20)
ylabel('I','FontSize',20)
set(gca,'FontSize',20) 