clear 
clc
syms k a1 a2 a3 a4 d1 d2;
a1=1;
a2 =0.5;
a3=3;
a4=1.8;
d2=0.01;
for d1=[1 1.1 4]
a11=d1*d2;
a22=-2*a1*a1*a3*a4*d1/(a1*a1*a3+a2*a4*a4)+a1*a1*a3*d2/(a4*a4)+a2*d2+a4*d1;
a33=a1*a1*a3/a4+a2*a4;
k=0:0.01:60;
cg=a11*k.^2+a22*k+a33;
plot(k,cg,'LineWidth',2)
hold on
end
plot(k(1:100:end),cg(1:100:end)*0,'.')
xlabel('k^2','FontSize',20)
ylabel('p_2(k^2)','FontSize',20)
legend('d_1=1','d_1=1.1','d_1=4','FontSize',15)
set(gca,'FontSize',20) 