clear 
clc
syms k a1 a2 a3 a4 d1 d2;
a1=1;
a2 =0.5;
a3=3;
a4=1.8;
i=0;
for d2=0:0.1:10
    i=i+1;
% d1=1000000;
% a11=d1.*d2;
% a22=-2*a1*a1*a3*a4.*d1/(a1*a1*a3+a2*a4*a4)+a1*a1*a3*d2/(a4*a4)+a2*d2+a4.*d1;
% a33=a1*a1*a3/a4+a2*a4;
% cg1=2*sqrt(a22.*a22-4*a11.*a33);
j=0;
for d1=0:800
    j=j+1;
a11=d1.*d2;
a22=-2*a1*a1*a3*a4.*d1/(a1*a1*a3+a2*a4*a4)+a1*a1*a3*d2/(a4*a4)+a2*d2+a4.*d1;
a33=a1*a1*a3/a4+a2*a4;
cg(i,j)=sqrt(a22.*a22-4*a11.*a33)./a11; 
end
end
d2=0:0.1:10;
d1=0:800;
surf(d1,d2,real(cg))
title('The distribution of instability mode');
xlabel('d_1');
ylabel('d_2');
view(-41.9,69.5)
colormap jet;
shading interp 
set(gca,'FontSize',20) 