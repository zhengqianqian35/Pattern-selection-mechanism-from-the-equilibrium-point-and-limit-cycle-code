clear
clc
a1=1;
a2=0.2095920262;%0.7980981536e-1;
a3=3;
a4=1.8;
u(1)=1.1;
v(1)=0.9;
nt=10000;
h=0.01;
 tau=0.0;
    for i=1:nt   
%         if(i>fix(tau/h))
%             ud=u(i-fix(tau/h));
%             vd=v(i-fix(tau/h));
%         else
%             ud=0;
%             vd=0;
%         end  
    u(i+1)=u(i)+h*(a1-a2*u(i)-a3*u(i)*v(i)^2); 
    v(i+1)=v(i)+h*(a2*u(i)+a3*u(i)*v(i)^2-a4*v(i));
    end
    s=0;
    if(s<2)
    for j=1:nt/2-2
 if((v(nt/2+j)-v(nt/2+j+1))<0&v(nt/2+j+2)-v(nt/2+j+1)<0)
    s=s+1;
    s3(s)=nt/2+j+1;
 end
    end
    end
 b11=mean(-a2-a3*v(s3(1):s3(2)).^2);
 b12=mean(-2*a3*u(s3(1):s3(2)).*v(s3(1):s3(2))); 
 b21=mean(a2+a3*v(s3(1):s3(2)).^2);
 b22=mean(2*a3*u(s3(1):s3(2)).*v(s3(1):s3(2))-a4);   
 for d1=[13 15 20]
 d2=1;
x=0:0.01:2;
t1=d1*d2*x.^2-(d1*b22+d2*b11)*x+b11*b22-b12*b21;
plot(x,t1,'LineWidth',2)
  hold on 
 end
   plot(x(1:5:end),t1(1:5:end)*0,'.')
 legend('d_1=13','d_1=15','d_1=20','p_{22}(k^2)=0','FontSize',16)
 xlabel('k^2','FontSize',20)
 ylabel('p_{22}(k^2)','FontSize',20)
% legend('S','I','FontSize',20)
set(gca,'FontSize',20) 