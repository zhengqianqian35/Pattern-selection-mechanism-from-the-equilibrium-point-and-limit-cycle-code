clear
clc
a1=1;
a2=0.5;%0.7980981536e-1;
a3=3;
a4=1.8;
u(1)=1.1;
v(1)=0.9;
nt=10000;
h=0.01;
 tau=0.0;
    for i=1:nt   
        if(i>fix(tau/h))
            ud=u(i-fix(tau/h));
            vd=v(i-fix(tau/h));
        else
            ud=0;
            vd=0;
        end  
    u(i+1)=u(i)+h*(a1-a2*ud-a3*u(i)*v(i)^2); 
    v(i+1)=v(i)+h*(a2*ud+a3*u(i)*v(i)^2-a4*v(i));
    end
plot((0:nt)*h,u,'LineWidth',2)
hold on 
plot((0:nt)*h,v,'LineWidth',2)
xlabel('t','FontSize',20)
legend('S','I','FontSize',20)
set(gca,'FontSize',20) 