clear 
clc
syms k a1 a2 a3 a4 d1 d2;
a1=1;
a2 =0.5;
a3=3;
a4=1.8;
d1=50;
% d1=1000000;
% a11=d1.*d2;
% a22=-2*a1*a1*a3*a4.*d1/(a1*a1*a3+a2*a4*a4)+a1*a1*a3*d2/(a4*a4)+a2*d2+a4.*d1;
% a33=a1*a1*a3/a4+a2*a4;
% cg1=2*sqrt(a22.*a22-4*a11.*a33);

d2=0:0.01:1.5;
a11=d1.*d2;
a22=-2*a1*a1*a3*a4.*d1/(a1*a1*a3+a2*a4*a4)+a1*a1*a3*d2/(a4*a4)+a2*d2+a4.*d1;
a33=a1*a1*a3/a4+a2*a4;
cg=sqrt(a22.*a22-4*a11.*a33)./a11;
plot(d2,cg,'LineWidth',2)
xlabel('d_2','FontSize',20)
ylabel('Instability mode','FontSize',20)
%legend('d_1=1','d_1=2','FontSize',20)
set(gca,'FontSize',20) 